To run the program, do:
`/merge_files.py test_input merged_output.txt`
